/*Q50: Write a program to print the following pattern:
*****
****
***
**
*


Sample Test Cases:
Input 1:
(No input required)
Output 1:
*****
****
***
**
*

*/

#include <stdio.h>

int main() {
    int rows = 5;

    for (int i = rows; i >= 1; i--) {
        for (int j = 1; j <= i; j++) {
            printf("*");
        }
        printf("\n");
    }

    return 0;
}
